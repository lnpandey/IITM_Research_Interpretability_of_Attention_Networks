### synthetic elliptical blobs 5d data 
n_classes = 10
k value = 9 
bg = 7
fg = 3
FC -> 5-6-12-1
classification -> 5-6-12-3
  
#### averaged over 20 runs
|layer averaged at| FTPT | FFPT | FTPF|  FFPF |
| - | - | - | - | - |
| zeroth | 88.51  | 11.42  | 0.065 | 0.00167 |
| first | 93.39  | 6.58   |  0.0166 | 0.0166  |
| second | 96.75 | 3.23 | 0.0183  | 0.00166 |
